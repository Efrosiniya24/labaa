package Candy;

public interface Calculate {
    double func(double[] n);
}
